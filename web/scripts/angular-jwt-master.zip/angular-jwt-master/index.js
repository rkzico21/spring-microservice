require('./dist/angular-jwt.js');
module.exports = 'angular-jwt';

